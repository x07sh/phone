TUI app to read Phone Calls and SMS from Quectel model using ModemManager/mmcli
